using AIResetRadar.App.Platforms.Windows;
using AIResetRadar.App.Services;
using AIResetRadar.Core;
namespace AIResetRadar.App;

public sealed partial class MainPage
{
    Border? banner;
    string? bannerAccountId;
    void DismissBanner(string accountId)
    {
        if (bannerAccountId != accountId) return;
        if (banner is not null) root.Children.Remove(banner);
        banner = null; bannerAccountId = null;
    }
    async Task ShowAlertAccountAsync(string accountId)
    {
        ShowMain();
        while (AppPanels.IsOpen) await AppPanels.CloseAsync();
        foreach (var entry in notificationCards) { entry.Value.Stroke = Color.FromArgb("#383B46"); entry.Value.StrokeThickness = 1; }
        highlightedAccount = accountId;
        Render();
        if (notificationCards.TryGetValue(accountId, out var card))
        {
            card.Stroke = Color.FromArgb("#C3ADF8"); card.StrokeThickness = 3;
            await dashboardScroll.ScrollToAsync(card, ScrollToPosition.Center, true);
            Dispatcher.StartTimer(TimeSpan.FromSeconds(6), () => {
                if (highlightedAccount == accountId) { highlightedAccount = null; if (notificationCards.TryGetValue(accountId, out var current)) { current.Stroke = Color.FromArgb("#383B46"); current.StrokeThickness = 1; } }
                return false;
            });
        }
    }
    string AlertProvider(string accountId) => state.Accounts.FirstOrDefault(a => a.Id == accountId)?.Provider ?? "Scrooge";
    static string ProviderImage(string provider) => provider switch { "OpenAI" => "openai.png", "Claude" => "claude.png", "GitHub Copilot" => "github.png", _ => "token_baron.png" };
    void ShowBanner(AlertEvent alert)
    {
        if (banner is not null) root.Children.Remove(banner);
        var severityColor = alert.Severity switch { ReminderSeverity.Critical => "#F05B69", ReminderSeverity.Warning => "#F2C94C", ReminderSeverity.Info => "#58A6FF", _ => "#C3ADF8" };
        var detail = new VerticalStackLayout { Spacing = 10 };
        var heading = new Grid { ColumnDefinitions = [new(GridLength.Auto), new(GridLength.Star)], ColumnSpacing = 12 };
        heading.Add(new Image { Source = ProviderImage(AlertProvider(alert.AccountId)), WidthRequest = 38, HeightRequest = 38, VerticalOptions = LayoutOptions.Center });
        var title = new VerticalStackLayout { Spacing = 3 };
        title.Children.Add(new Label { Text = AlertProvider(alert.AccountId) == "OpenAI" ? "OpenAI Codex" : AlertProvider(alert.AccountId), FontSize = 12, TextColor = Color.FromArgb("#C3ADF8") });
        title.Children.Add(new Label { Text = alert.Title, TextColor = Color.FromArgb(severityColor), FontFamily = "Segoe UI Semibold", FontSize = 15 });
        heading.Add(title, 1); detail.Children.Add(heading);
        detail.Children.Add(new Label { Text = alert.Detail, FontSize = 12, TextColor = Color.FromArgb("#B6B8C8") });
        var actions = new HorizontalStackLayout { Spacing = 8 };
        Border? displayedBanner = null;
        var view = new AIResetRadar.App.Controls.ActionButton { Text = "Show Info" };
        var snooze = new AIResetRadar.App.Controls.ActionButton { Text = "Snooze 1 Hour" }; var dismiss = new AIResetRadar.App.Controls.ActionButton { Text = "Dismiss" };
        view.Clicked += async (_, _) => { AlertSounds.Play(preferences, "info"); Dismiss(); await ShowAlertAccountAsync(alert.AccountId); };
        snooze.Clicked += async (_, _) =>
        {
            if (await SaveSnoozeAsync(alert.AccountId)) { AlertSounds.Play(preferences, "snooze"); Dismiss(); }
            else await AIResetRadar.App.Services.ThemedDialogs.ShowAsync(this, "Snooze not saved", "Alerts remain active. Check available space and folder access, then try Snooze again.", "Close");
        };
        dismiss.Clicked += (_, _) => { AlertSounds.Play(preferences, "dismiss"); Dismiss(); }; actions.Children.Add(view); actions.Children.Add(snooze); actions.Children.Add(dismiss); detail.Children.Add(actions);
        banner = new Border { Padding = 18, Content = detail, Stroke = Color.FromArgb(severityColor), BackgroundColor = Color.FromArgb("#222329"),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 14 }, MaximumWidthRequest = 520,
            HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.End, Margin = new Thickness(20) };
        root.Add(banner, 0, 2);
        bannerAccountId = alert.AccountId;
        displayedBanner = banner;
        void Dismiss()
        {
            // A completed snooze must not dismiss a newer banner shown while saving.
            if (ReferenceEquals(banner, displayedBanner)) DismissBanner(alert.AccountId);
        }
    }
    async Task OpenHistoryAsync()
    {
        alertHistory.RemoveAll(e => e.CreatedAt < HistoryRetention.Cutoff(DateTimeOffset.UtcNow, preferences.HistoryRetentionDays));
        var page = new ContentPage { Title = "Alert history", BackgroundColor = Color.FromArgb("#141519") };
        var content = new VerticalStackLayout { Padding = 28, Spacing = 16 };
        content.Children.Add(new Label { Text = "Alert history", FontSize = 26, FontFamily = "Segoe UI Semibold" });
        if (NotificationService.Current.Problem is { } problem) content.Children.Add(new Label { Text = problem, TextColor = Color.FromArgb("#EAAA51") });
        if (alertHistory.Count == 0) content.Children.Add(new Label { Text = "No alerts yet. Low capacity and expiring resets will appear here." });
        foreach (var alert in alertHistory.OrderByDescending(a => a.CreatedAt))
        {
            var item = new AIResetRadar.App.Controls.ActionButton { Text = $"{TimeZones.Format(alert.CreatedAt, DisplayZone, "MMM d, h:mm tt")} · {alert.Title}\n{alert.Detail}\n{(alert.Delivered ? "Sent to Windows" : "Recorded in history")}", HeightRequest = -1, MinimumHeightRequest = 80 };
            item.Clicked += (_, _) => OpenAccount(alert.AccountId, alert.WindowId); content.Children.Add(item);
        }
        var back = new AIResetRadar.App.Controls.ActionButton { Text = "Close" }; back.Clicked += async (_, _) => await AppPanels.CloseAsync(); content.Children.Add(back);
        page.Content = new ScrollView { Content = content }; await AppPanels.ShowAsync(this, page);
    }
    async Task TestNotificationAsync()
    {
        var id = state.Accounts.FirstOrDefault()?.Id ?? "test";
        var alert = new AlertEvent("test/" + Guid.NewGuid().ToString("N"), id, null, "Scrooge Notification Test", "This is a test. Your account usage has not changed.", DateTimeOffset.UtcNow);
        try { if (!await RecordAlertIntentAsync(alert)) return; }
        catch { await AIResetRadar.App.Services.ThemedDialogs.ShowAsync(this, "Local history unavailable", "Scrooge could not record the test notification. Check available space and folder access, then try again.", "Close"); return; }
        var sent = NotificationService.Current.Show(alert, preferences with { Notifications = true }, AlertProvider(id));
        var deliverySaved = true;
        try { await MarkAlertDeliveredAsync(alert, sent); } catch { deliverySaved = false; }
        await AppPanels.CloseAsync(); ShowBanner(alert); AlertSounds.Play(preferences, "alert");
        if (!sent) await AIResetRadar.App.Services.ThemedDialogs.ShowAsync(this, "Notification test", NotificationService.Current.Problem ?? "Windows did not confirm delivery. The test is recorded in history.", "OK");
        else if (!deliverySaved) await AIResetRadar.App.Services.ThemedDialogs.ShowAsync(this, "Notification test", "Windows accepted the notification, but Scrooge could not save the delivery status. The test will not be replayed.", "Close");
    }
}
