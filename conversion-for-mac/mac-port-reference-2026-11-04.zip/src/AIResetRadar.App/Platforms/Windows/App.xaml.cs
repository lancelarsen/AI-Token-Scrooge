namespace AIResetRadar.App.WinUI;
public partial class App : MauiWinUIApplication
{
    readonly Mutex instance;
    public App()
    {
        var installation = AIResetRadar.Infrastructure.UpdateInstallation.RootFor(AppContext.BaseDirectory);
        var active = AIResetRadar.Infrastructure.UpdateInstallation.ApplicationDirectory(installation);
        if (File.Exists(AIResetRadar.Infrastructure.UpdateInstallation.Launcher(installation)) &&
            (!Path.TrimEndingDirectorySeparator(active).Equals(Path.TrimEndingDirectorySeparator(AppContext.BaseDirectory), StringComparison.OrdinalIgnoreCase) ||
             !Path.TrimEndingDirectorySeparator(AppContext.BaseDirectory).Equals(Environment.GetEnvironmentVariable("SCROOGE_LAUNCHED_DIRECTORY"), StringComparison.OrdinalIgnoreCase)))
        {
            var start = new System.Diagnostics.ProcessStartInfo(AIResetRadar.Infrastructure.UpdateInstallation.Launcher(installation)) { UseShellExecute = false };
            foreach (var argument in Environment.GetCommandLineArgs().Skip(1)) start.ArgumentList.Add(argument);
            System.Diagnostics.Process.Start(start);
            Environment.Exit(0);
        }
        instance = new Mutex(true, "Local\\AIResetRadar.Desktop", out var created);
        if (!created)
        {
            var hwnd = FindWindow(null, "AI Token Scrooge");
            // Restore an older running preview during an upgrade, too.
            if (hwnd == 0) hwnd = FindWindow(null, "AI Reset Radar");
            if (hwnd != 0) { ShowWindow(hwnd, 9); SetForegroundWindow(hwnd); }
            Environment.Exit(0);
        }
        _ = AIResetRadar.App.Platforms.Windows.NotificationService.Current;
        UnhandledException += (_, e) => {
            var recoveredFocusEvent = AIResetRadar.App.Platforms.Windows.FocusEventFailure.IsKnown(e.Exception);
            if (recoveredFocusEvent) e.Handled = true;
            // Keep provider messages and credentials out of diagnostics. The HRESULT
            // distinguishes WinUI focus/projection failures with identical stacks.
            try
            {
                var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AIResetRadar");
                Directory.CreateDirectory(path);
                File.WriteAllText(Path.Combine(path, recoveredFocusEvent ? "last-focus-recovery.log" : "last-crash.log"),
                    $"{DateTimeOffset.UtcNow:O}\n{e.Exception.GetType().Name} HRESULT=0x{e.Exception.HResult:X8}\n{e.Exception.StackTrace}");
            }
            catch { /* Diagnostic failure must not replace the original exception. */ }
        };
        InitializeComponent();
    }
    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
    [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)] static extern nint FindWindow(string? className, string title);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ShowWindow(nint hwnd, int command);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool SetForegroundWindow(nint hwnd);
}
