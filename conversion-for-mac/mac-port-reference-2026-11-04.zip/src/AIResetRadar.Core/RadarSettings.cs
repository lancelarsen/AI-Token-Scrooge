namespace AIResetRadar.Core;
public sealed record RadarSettings(bool Notifications = true, bool Sound = true, bool Privacy = false,
    bool QuietHours = true, int QuietStartHour = 0, int QuietEndHour = 8, decimal LowThreshold = 30,
    decimal CriticalThreshold = 10, bool LaunchAtSignIn = true, bool CloseToTray = true, IReadOnlyList<AlertRule>? Rules = null,
    string TimeZoneId = TimeZones.DefaultId, AccountSortMode AccountSort = AccountSortMode.CustomOrder,
    IReadOnlyList<string>? AccountOrder = null, IReadOnlyList<QuotaAlertSection>? DisabledCapacityAlerts = null, string SoundTheme = "Ducks", double SoundVolume = 65,
    IReadOnlyList<TimedReminder>? ResetExpiryReminders = null, IReadOnlyList<TimedReminder>? QuotaRefreshReminders = null, decimal InfoThreshold = 50, bool AlertOnIcon = true, int ReminderDefaultsVersion = 0, IReadOnlyList<string>? CustomLineColors = null, int HistoryRetentionDays = HistoryRetention.Days, bool CheckForNewerVersions = true)
{
    public IReadOnlyList<TimedReminder> EffectiveResetReminders => ResetExpiryReminders ?? TimedReminder.Defaults(true);
    public IReadOnlyList<TimedReminder> EffectiveRefreshReminders => QuotaRefreshReminders ?? TimedReminder.Defaults(false);
    public RadarSettings UpgradeReminderDefaults()
    {
        if (ReminderDefaultsVersion >= 2) return this;
        IReadOnlyList<TimedReminder>? Upgrade(IReadOnlyList<TimedReminder>? reminders) => reminders?.Select(r =>
            ReminderDefaultsVersion < 1 && r.Id == "default-72" && r.Hours == 72 && r.Severity == ReminderSeverity.Info
                ? r with { Severity = ReminderSeverity.Warning }
                : r.Id == "default-48" && r.Hours == 48 && r.Severity == ReminderSeverity.Warning
                    ? r with { Severity = ReminderSeverity.Critical } : r).ToArray();
        return this with { ResetExpiryReminders = Upgrade(ResetExpiryReminders), QuotaRefreshReminders = Upgrade(QuotaRefreshReminders), ReminderDefaultsVersion = 2 };
    }
    public bool CapacityAlertsEnabled(string accountId, string windowId) =>
        !(DisabledCapacityAlerts ?? []).Any(section => section.AccountId == accountId && section.WindowId == windowId);
    public RadarSettings WithCapacityAlerts(string accountId, string windowId, bool enabled)
    {
        var disabled = (DisabledCapacityAlerts ?? []).Where(section => section.AccountId != accountId || section.WindowId != windowId).ToList();
        if (!enabled) disabled.Add(new(accountId, windowId));
        return this with { DisabledCapacityAlerts = disabled.ToArray() };
    }
    public RadarSettings WithWindowThresholds(string accountId, string windowId, decimal low, decimal critical, decimal? info = null)
    {
        if (!new AlertThresholds(low, critical, info ?? Math.Max(InfoThreshold, low)).IsValid) throw new ArgumentOutOfRangeException(nameof(low), "Use 0 ≤ critical < warning ≤ 100.");
        var stored = Rules?.FirstOrDefault(rule => rule.AccountId == accountId && rule.WindowId == windowId)
            ?? Rules?.FirstOrDefault(rule => rule.AccountId == accountId && rule.WindowId is null) ?? new AlertRule(accountId);
        var updated = stored with { WindowId = windowId, LowThreshold = low, CriticalThreshold = critical, InfoThreshold = info ?? Math.Max(InfoThreshold, low) };
        return this with { Rules = (Rules ?? []).Where(rule => rule.AccountId != accountId || rule.WindowId != windowId).Append(updated).ToArray() };
    }
    public bool HasValidThresholds => Valid(LowThreshold, CriticalThreshold) && InfoThreshold >= LowThreshold && InfoThreshold <= 100 && (Rules ?? []).All(r =>
    {
        var effective = RuleFor(r.AccountId, r.WindowId); return Valid(effective.LowThreshold!.Value, effective.CriticalThreshold!.Value) && effective.InfoThreshold >= effective.LowThreshold && effective.InfoThreshold <= 100;
    });
    static bool Valid(decimal low, decimal critical) => critical >= 0 && critical < low && low <= 100;
    public AlertRule RuleFor(string accountId, string? windowId = null)
    {
        var account = Rules?.FirstOrDefault(r => r.AccountId == accountId && r.WindowId is null) ?? new(accountId);
        var window = windowId is null ? account : Rules?.FirstOrDefault(r => r.AccountId == accountId && r.WindowId == windowId) ?? account;
        return window with { LowThreshold = window.LowThreshold ?? account.LowThreshold ?? LowThreshold,
            CriticalThreshold = window.CriticalThreshold ?? account.CriticalThreshold ?? CriticalThreshold,
            InfoThreshold = window.InfoThreshold ?? account.InfoThreshold ?? Math.Max(InfoThreshold, window.LowThreshold ?? account.LowThreshold ?? LowThreshold) };
    }
}

public sealed record QuotaAlertSection(string AccountId, string WindowId);

public sealed record AlertRule(string AccountId, string? WindowId = null, decimal? LowThreshold = null,
    decimal? CriticalThreshold = null, bool Low = true, bool Critical = true, bool Exhausted = true, bool Restored = true, bool Expiry = true, decimal? InfoThreshold = null, bool Info = true);
